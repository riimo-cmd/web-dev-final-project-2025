

console.log("hi")
let nav = document.getElementById("navbar");

nav.innerHTML += "<ul></ul>";

/*<li><a href="./index.html">Home</a></li>
        <li><a href="./index.html">About</a></li>
        <li><a href="./index.html">Recipes</a></li>
        <li><a href="./index.html">Submit</a></li>*/